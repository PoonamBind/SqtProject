package com.auto.example;

import com.browser.www.Browser_Example;

public class Executor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Browser_Example browsers = new Browser_Example();
		//	browsers.chrome();
			browsers.Firefox();
			//browsers.edge();
			browsers.ie();
		}

	}

